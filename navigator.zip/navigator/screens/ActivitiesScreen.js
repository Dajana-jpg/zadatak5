import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function ActivitiesScreen({ route, navigation }) {

function handleHomePress(){
  navigation.navigate("Home")
}
function handleSettingsPress(){
  navigation.navigate("Settings")
}
function handleProfilePress(){
  navigation.navigate("Profile")
}

  return (
    <View style={styles.screen}>
      <Text>HOME SCREEN</Text>
      <Button 
      title="GO TO THE HOME SCREEN"
      onPress={handleHomePress}
       />
       <Button 
      title="GO TO THE SETTINGS SCREEN"
      onPress={handleSettingsPress}
       />
        <Button 
      title="GO TO THE PROFILE SCREEN"
      onPress={handleProfilePress}
       />
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center"
  }
});

import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function SettingsScreen({ route, navigation }) {

function handleHomePress(){
  navigation.navigate("Home")
}
function handleProfilePress(){
  navigation.navigate("Profile")
}
function handleActivitiesPress(){
  navigation.navigate("Activities")
}
  return (
    <View style={styles.screen}>
      <Text>SETTING SCREEN</Text>
      <Button 
      title="GO TO THE HOME SCREEN"
      onPress={handleHomePress}
       />
       <Button 
      title="GO TO THE PROFILE SCREEN"
      onPress={handleProfilePress}
       />
       <Button 
      title="GO TO THE ACTIVITIES SCREEN"
      onPress={handleActivitiesPress}
       />
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center"
  }
});

import * as React from 'react';
import { Text, View, StyleSheet, Button, Image } from 'react-native';

export function ProfileScreen({ route, navigation }) {

function handleHomePress(){
  navigation.navigate("Home")
}
function handleSettingsPress(){
  navigation.navigate("Settings")
}
function handleActivitiesPress(){
  navigation.navigate("Activities")
}
  return (
    <View style={styles.screen}>
      <Text>pROfiLE SCREEN</Text>
      <Image
            source={{
              uri: 'https://i.kym-cdn.com/photos/images/newsfeed/001/253/025/34d.jpg',
            }}
            style={{ width: 300, height: 300 }}
          />
      <Button 
      title="GO TO THE HOME SCREEN"
      onPress={handleHomePress}
       />
       <Button 
      title="GO TO THE SETTINGS SCREEN"
      onPress={handleSettingsPress}
       />
        <Button 
      title="GO TO THE ACTIVITIES SCREEN"
      onPress={handleActivitiesPress}
       />
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignContent: "center",
    justifyContent: "center"
  }
});
